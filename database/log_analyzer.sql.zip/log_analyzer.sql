-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 20, 2017 at 06:10 PM
-- Server version: 5.7.18
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `log_analyzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `case_details`
--

DROP TABLE IF EXISTS `case_details`;
CREATE TABLE IF NOT EXISTS `case_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `case_no` varchar(200) NOT NULL,
  `ref_no` varchar(200) NOT NULL,
  `site_url` varchar(255) NOT NULL,
  `evidence_file` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `registered_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `public_ip` varchar(100) NOT NULL,
  `fail_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `log_access`
--

DROP TABLE IF EXISTS `log_access`;
CREATE TABLE IF NOT EXISTS `log_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_no` varchar(200) NOT NULL,
  `public_ip` varchar(15) NOT NULL,
  `date_time` datetime NOT NULL,
  `timezone` varchar(5) NOT NULL,
  `method` varchar(10) NOT NULL,
  `http_header` varchar(500) NOT NULL,
  `http_response` int(3) NOT NULL,
  `file_bytes` varchar(200) NOT NULL,
  `link_ref` text NOT NULL,
  `useragent` text NOT NULL,
  `browser` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `log_sys`
--

DROP TABLE IF EXISTS `log_sys`;
CREATE TABLE IF NOT EXISTS `log_sys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_no` varchar(200) NOT NULL,
  `public_ip` varchar(15) NOT NULL,
  `date_time` datetime NOT NULL,
  `protocol` varchar(100) NOT NULL,
  `notification` varchar(100) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(200) NOT NULL,
  `l_name` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `role` varchar(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_pic` varchar(200) NOT NULL,
  `register_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `f_name`, `l_name`, `email`, `gender`, `dob`, `role`, `username`, `password`, `profile_pic`, `register_time`) VALUES
(1, 'Cyberdome', 'Admin', 'admin@cyberdome.com', 'male', '2017-01-01', 'admin', 'admin', '$2y$10$ubsIdDdePlkAcX0yIv7uMOzpe0DExStWwuLpnmqehXIFxsPV.U32i', '1487684845_12246.PNG', '2017-07-15 16:58:14'),
(2, 'Cyberdome', 'User', 'user@cyberdome.com', 'male', '2017-01-01', 'user', 'user', '$2y$10$8upDIKAF5rsgkVxiJeng7OzRQKou6DSx71huh31oHcQfMW2g9zZBu', '1491423924_85971.PNG', '2017-07-16 15:04:11'),
(3, 'Adarsh', 'VS', 'adarsh@loganalyzer.com', 'male', '1996-01-01', 'admin', 'adarsh', '$2y$10$ZhW3hM7wSUFmjtTfWdpmLui/aUnfvOH3Thm1fOLxSVSFpu9b6mh.G', '1479994248_72350.PNG', '2017-07-27 12:13:33');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
